// Fastor legacy shim: product pages now use app.js and product.html.
(function(){
  const CART_KEY='fastor_cart';
  function qs(s){return document.querySelector(s)}
  function cart(){try{return JSON.parse(localStorage.getItem(CART_KEY)||'[]')}catch{return []}}
  function count(){return cart().reduce((n,i)=>n+Number(i.quantity||1),0)}
  function update(){document.querySelectorAll('[data-cart-count]').forEach(e=>{e.textContent=count();});}
  document.addEventListener('DOMContentLoaded', update);
})();
